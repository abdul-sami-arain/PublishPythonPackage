from setuptools import setup

setup (name="StatisticVibes",
version="0.1",
description="this is a package",
long_description="this is a very very long description",
author = "Abdul Sami",
packages = ["StatisticVibes"],
install_packages = []
)